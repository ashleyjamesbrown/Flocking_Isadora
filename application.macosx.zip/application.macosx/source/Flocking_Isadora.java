import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 
import netP5.*; 
import oscP5.*; 
import codeanticode.syphon.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Flocking_Isadora extends PApplet {


//
// Ashley James Brown
//
// Client: Bill Cottman
// Title:  Flocking_Isadora
// Date:   July 2017 
//
// tested on 10.12.5 corei5 processing 3.2.1 java 8 hd3000 gfx and geforce gt750m


// Rules: Cohesion, Separation, Alignment


//boid speed and force
float gmaxForce=0.05f; //default 0.05
float gmaxSpeed=8; //default 3

//comntrols for S,A,C
float gSep =25.0f; //default 25 . lower number closer togther, higher number furtehr apart
float gAli=50; //default is 50. neighbour distance for alignment
float gCoh=50; //default is 50. neighbour distance for cohesion 

//weighting for S,A,C
float wSep=1.5f; //default 1.5
float wAli=1.0f; //default 1
float wCoh=1.0f; //default 1



Flock flock; //global arraylist 

float r=255;
float g=255;
float b=255;

boolean texturing=true;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
public void settings() {
  size(1200, 800, P3D);
}

public void setup() {  
  background(255);
  setupControls();
  flock = new Flock();

  // Add an initial set of 100 boids into the system
  for (int i = 0; i < 100; i++) {
    Boid b = new Boid(width/2, height/2);
    flock.addBoid(b);
  }

  loadRenderEngine();
  setupOSC();
}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
public void draw() {

  if (bkg) {
    int currentColor = lerpColor(fromColor, toColor, currentLerpValue);

    currentLerpValue += lerpStep;
    if (currentLerpValue >= 1) {
      fromColor = currentColor;
      toColor= getRandomColor();
      currentLerpValue = 0;
    }

    background(currentColor);
  } else {
    background(r, g, b);
  }
  
  
  flock.run(); //apply all forces in realtime - osc is already threading and listening and will update global variables in real time

  if (texturing) {
    renderBoids(); //texture render onto teh boids
  } else {
    textureMode(NORMAL);
  }

  //syphon out
}






// Add a new boid into the System
public void mouseDragged() {
  flock.addBoid(new Boid(mouseX, mouseY));
}


public void keyPressed() {
  switch (key) {
  case 's' :
    saveFrame("./images/flockingIsadora-###.tiff");
    break;
  case 't' :
    texturing=!texturing;
    break;
  }
}

// taken and modified from The Nature of Code

// Boid class for each individual boid in the system

// Methods for Separation, Cohesion, Alignment added alongside a ton of global parameters for control and switching rules on/off

//

class Boid {

  PVector position;
  PVector velocity;
  PVector acceleration;
  float r;
  float maxforce;    // Maximum steering force
  float maxspeed;    // Maximum speed

  Boid(float x, float y) {
    acceleration = new PVector(0,0);
    velocity = new PVector(random(-1,1),random(-1,1));
    position = new PVector(x,y);
    r = 3.0f; //used for render sizing
    
    maxspeed = gmaxSpeed;
    maxforce = gmaxForce;
  }


  public void run(ArrayList<Boid> boids) {
    flock(boids); //apply SEP, ALI, COH methods
    update(); //update position based on forces and rules
    borders(); //check if offscreen and wraparound
    
    if (!texturing){
    render();
    }
    
    updateMaxSpeed();
    updateMaxForce();
  }

 
 public void updateMaxSpeed(){
   maxspeed = gmaxSpeed;
 }
 
 public void updateMaxForce(){
   maxforce = gmaxForce;
 }


  public void applyForce(PVector force) {
    // We could add mass here if we want A = F / M
    acceleration.add(force);
  }


  // We accumulate a new acceleration each time based on three rules
  public void flock(ArrayList<Boid> boids) {
    PVector sep = separate(boids);   // Separation
    PVector ali = align(boids);      // Alignment
    PVector coh = cohesion(boids);   // Cohesion
    
    // Arbitrarily weight these forces
    sep.mult(wSep);
    ali.mult(wAli);
    coh.mult(wCoh);
    
    // Add the force vectors to acceleration
    applyForce(sep);
    applyForce(ali);
    applyForce(coh);
  }

  // Method to update position
  public void update() {
    // Update velocity
    velocity.add(acceleration);
    // Limit speed
    velocity.limit(maxspeed);
    position.add(velocity);
    // Reset accelertion to 0 each cycle
    acceleration.mult(0);
  }

  // A method that calculates and applies a steering force towards a target
  // STEER = DESIRED MINUS VELOCITY
  public PVector seek(PVector target) {
    PVector desired = PVector.sub(target,position);  // A vector pointing from the position to the target
    // Normalize desired and scale to maximum speed
    desired.normalize();
    desired.mult(maxspeed);
    // Steering = Desired minus Velocity
    PVector steer = PVector.sub(desired,velocity);
    steer.limit(maxforce);  // Limit to maximum steering force
    return steer;
  }
  
  public void render() {
    // Draw a triangle rotated in the direction of velocity
    float theta = velocity.heading2D() + radians(90);
    fill(175);
    stroke(0);
    pushMatrix();
    translate(position.x,position.y);
    rotate(theta);
    beginShape(TRIANGLES);
    vertex(0, -r*2);
    vertex(-r, r*2);
    vertex(r, r*2);
    endShape();
    popMatrix();
  }

  // Wraparound if going offscreen to continue opposite side
  public void borders() {
    if (position.x < -r) position.x = width+r;
    if (position.y < -r) position.y = height+r;
    if (position.x > width+r) position.x = -r;
    if (position.y > height+r) position.y = -r;
  }
  
  

  // Separation
  // Method checks for nearby boids and steers away
  public PVector separate (ArrayList<Boid> boids) {
    
    float desiredseparation = gSep;
    
    PVector steer = new PVector(0,0,0);
    int count = 0;
    // For every boid in the system, check if it's too close
    for (Boid other : boids) {
      float d = PVector.dist(position,other.position);
      // If the distance is greater than 0 and less than an arbitrary amount (0 when you are yourself)
      if ((d > 0) && (d < desiredseparation)) {
        // Calculate vector pointing away from neighbor
        PVector diff = PVector.sub(position,other.position);
        diff.normalize();
        diff.div(d);        // Weight by distance
        steer.add(diff);
        count++;            // Keep track of how many
      }
    }
    // Average -- divide by how many
    if (count > 0) {
      steer.div((float)count);
    }

    // As long as the vector is greater than 0
    if (steer.mag() > 0) {
      // Implement Reynolds: Steering = Desired - Velocity
      steer.normalize();
      steer.mult(maxspeed);
      steer.sub(velocity);
      steer.limit(maxforce);
    }
    return steer;
  }

  // Alignment
  // For every nearby boid in the system, calculate the average velocity
  public PVector align (ArrayList<Boid> boids) {
    
    //distance from neighbour
    float neighbordist = gAli;
    
    PVector sum = new PVector(0,0);
    int count = 0;
    for (Boid other : boids) {
      float d = PVector.dist(position,other.position);
      if ((d > 0) && (d < neighbordist)) {
        sum.add(other.velocity);
        count++;
      }
    }
    if (count > 0) {
      sum.div((float)count);
      sum.normalize();
      sum.mult(maxspeed);
      PVector steer = PVector.sub(sum,velocity);
      steer.limit(maxforce);
      return steer;
    } else {
      return new PVector(0,0);
    }
  }

  // Cohesion
  // For the average position (i.e. center) of all nearby boids, calculate steering vector towards that position
  public PVector cohesion (ArrayList<Boid> boids) {
    
    //distance from neighbour
    float neighbordist = gCoh;
    
    PVector sum = new PVector(0,0);   // Start with empty vector to accumulate all positions
    int count = 0;
    for (Boid other : boids) {
      float d = PVector.dist(position,other.position);
      if ((d > 0) && (d < neighbordist)) {
        sum.add(other.position); // Add position
        count++;
      }
    }
    if (count > 0) {
      sum.div(count);
      return seek(sum);  // Steer towards the position
    } else {
      return new PVector(0,0);
    }
  }
}
// Taken from Nature Of Code

// Flock class
// Does very little, simply manages the ArrayList of all the boids

class Flock {
  public ArrayList<Boid> boids; // An ArrayList for all the boids

  Flock() {
    boids = new ArrayList<Boid>(); // Initialize the ArrayList
  }

  public void run() {
    for (Boid b : boids) {
      b.run(boids);  // Passing the entire list of boids to each boid individually
    }
  }

  //method to add more boids into the global arraylist
  public void addBoid(Boid b) {
    boids.add(b);
  }

}
int fromColor = getRandomColor();
int toColor = getRandomColor();

float currentLerpValue = 0;
float lerpStep = .001f;


boolean bkg = true;

public int getRandomColor() {
  return color(random(255), random(255), random(255));
}


ControlFrame cf;

public void setupControls(){
  cf = new ControlFrame(this, 400, 800, "Controls");
  surface.setLocation(420, 10); 
}

class ControlFrame extends PApplet {

  int w, h;
  PApplet parent;
  ControlP5 cp5;

  public ControlFrame(PApplet _parent, int _w, int _h, String _name) {
    super();   
    parent = _parent;
  
    w=_w;
    h=_h;
    PApplet.runSketch(new String[]{this.getClass().getName()}, this);
  }

  public void settings() {
    size(w, h);
  }

  public void setup() {
    surface.setLocation(10, 10);
    cp5 = new ControlP5(this);
    
    cp5.addToggle("Texture")
       .plugTo(parent, "texturing")
       .setPosition(10, 10)
       .setSize(30, 30)
       .setValue(true);
       
        cp5.addToggle("Background Colour Change")
       .plugTo(parent, "bkg")
       .setPosition(70, 10)
       .setSize(30, 30)
       .setValue(true);
       
    cp5.addSlider("Seperation_Amount")
       .plugTo(parent, "gSep")
       .setRange(2, 100)
       .setValue(25)
       .setPosition(10, 100)
       .setSize(200, 30);
       
       cp5.addSlider("Alignment_Amount")
       .plugTo(parent, "gAli")
       .setRange(2, 100)
       .setValue(50)
       .setPosition(10, 150)
       .setSize(200, 30);
       
        cp5.addSlider("Cohesion_Amount")
       .plugTo(parent, "gCoh")
       .setRange(2, 100)
       .setValue(50)
       .setPosition(10, 200)
       .setSize(200, 30);
       
       
       cp5.addSlider("Seperation_Weight")
       .plugTo(parent, "wSep")
       .setRange(0.1f, 2.0f)
       .setValue(1.5f)
       .setPosition(10, 300)
       .setSize(200, 30);
       
       cp5.addSlider("Alignment_Weight")
       .plugTo(parent, "wAli")
       .setRange(0.1f, 2.0f)
       .setValue(1.0f)
       .setPosition(10, 350)
       .setSize(200, 30);
       
        cp5.addSlider("Cohesion_Weight")
       .plugTo(parent, "wCoh")
       .setRange(0.1f, 2.0f)
       .setValue(1.0f)
       .setPosition(10, 400)
       .setSize(200, 30);
       
       cp5.addSlider("Max_Speed")
       .plugTo(parent, "gmaxSpeed")
       .setRange(1, 10)
       .setValue(3)
       .setPosition(10, 500)
       .setSize(200, 30);
       
         cp5.addSlider("Max_Force")
       .plugTo(parent, "gmaxForce")
       .setRange(0.01f, 1)
       .setValue(0.05f)
       .setPosition(10, 550)
       .setSize(200, 30);
       
  }

  public void draw() {
    background(0);
    
  }
}






OscP5 oscP5;
NetAddress myRemoteLocation;

public void setupOSC() {
  /* start oscP5, listening for incoming messages at port 12000 */
  oscP5 = new OscP5(this, 12000); //make sure to ammend isadora to send on port 12000
  myRemoteLocation = new NetAddress("127.0.0.1", 1234); //set isadora to listen to this port 1234 which it does buyd efault i think

  //all osc plugs coming from isadora
  oscP5.plug(this, "gmf", "/force");
  oscP5.plug(this, "gms", "/maxspeed");
}



public void gmf(float theA) {
  println("### plug event method. received a message");
  println("value is: "+theA);
}

public void gms(float theA) {
  println("### plug event method. received a message");
  println("value is: "+theA);
}







/* incoming osc message are forwarded to the oscEvent method. */
public void oscEvent(OscMessage theOscMessage) {
  if (theOscMessage.isPlugged()==false) {
    /* print the address pattern and the typetag of the received OscMessage */
    println("### received an osc message.");
    println("### addrpattern\t"+theOscMessage.addrPattern());
    println("### typetag\t"+theOscMessage.typetag());
  }
}






// ArrayList<Boid> boids;


PImage timg;
BoidRenderer br;

public void loadRenderEngine() {
  timg = loadImage("plane.png"); //plane.png  up.png  nav.png  paint.png

  br = new BoidRenderer(); //establish new render
}



public void renderBoids() {
  textureMode(IMAGE);
  br.renderBoids(flock, 2, 3);
}


class BoidRenderer {

  public void renderBoids(Flock flock, int delta, int sWeight) {
    //strokeWeight(sWeight);
    //stroke(0);

    noStroke();
    noFill();
    //tint(255,190);

    //blendMode(ADD);






    for (Boid b : flock.boids) {

      beginShape(QUAD);
      textureMode(IMAGE);
      texture(timg);


      float theta = b.velocity.heading2D() + radians(90);
      //fill(175);
      //stroke(0);
      pushMatrix();
      translate(b.position.x, b.position.y);
      rotate(theta);



      vertex(0, 0, 0, 0);
      vertex(18, 0, timg.width, 0);
      vertex(18, 18, timg.width, timg.height);
      vertex(0, 18, 0, timg.height);
      //image(timg,0,0);


      endShape();
      popMatrix();
    }
  }
}


SyphonServer server;

public void createServer() {
}


public void sendSyphonToIsadora() {
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Flocking_Isadora" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
